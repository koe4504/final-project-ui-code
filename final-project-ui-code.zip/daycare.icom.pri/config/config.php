<?php
session_start();
define('SITE_NAME', 'Daycare Management System');
?>

